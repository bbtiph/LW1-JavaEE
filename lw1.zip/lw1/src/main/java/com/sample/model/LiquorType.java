package
        com.sample.model;

public enum LiquorType {
    WINE,BEER,WHISKY
}
